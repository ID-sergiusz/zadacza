# Hanoj kontratakuje — materiały do nauki

**Zawartość archiwum:**

- `HAK_kurs_algorytmow_od_podstaw_PL.pdf` — podręcznik PDF w języku polskim, z diagramami i pełnym rozwiązaniem.
- `HAK_podrecznik_czysty_markdown_PL.md` — tekst podręcznika w przenośnym Markdownie (bez LaTeX-owych diagramów okładki).
- `hak.cpp` — pełne, działające rozwiązanie zadania w C++17.
- `test_hak.py` — niezależny symulator i 350 losowych testów rozwiązania.
- `przyklad_wejscie.txt` — przykład wejścia z podręcznika.
- `przyklad_wyjscie.txt` — wynik dla przykładu (27 ruchów).

## Jak uruchomić kod?

Na Linuksie, w terminalu w folderze z plikami:

```bash
g++ -std=c++17 -O2 -Wall -Wextra hak.cpp -o hak
./hak < przyklad_wejscie.txt > moj_wynik.txt
python3 test_hak.py ./hak
```

## Od czego zacząć?

W PDF przeczytaj najpierw lekcje 1–3 (podstawy), a następnie rozwiązuj przykład z lekcji 4–7 na kartce. Dopiero później czytaj kod z lekcji 11. Każde ćwiczenie ma odpowiedź w sekcji „Rozwiązania ćwiczeń”.
